"""create emails table

Revision ID: 0001
Revises:
Create Date: 2026-10-11

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "emails",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("sender", sa.String(length=255), nullable=False),
        sa.Column("subject", sa.String(length=500), nullable=False),
        sa.Column("body", sa.Text(), nullable=False),
        sa.Column("category", sa.String(length=100), nullable=True),
        sa.Column("priority", sa.String(length=50), nullable=True),
        sa.Column("summary", sa.Text(), nullable=True),
        sa.Column("processing_status", sa.String(length=50), nullable=False),
        sa.Column("analysis_source", sa.String(length=50), nullable=False),
        sa.Column("seed_key", sa.String(length=100), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("seed_key", name="uq_emails_seed_key"),
    )
    op.create_index(op.f("ix_emails_id"), "emails", ["id"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_emails_id"), table_name="emails")
    op.drop_table("emails")
