from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Email
from app.schemas import (
    EmailCreate,
    EmailListResponse,
    EmailRead,
    EmailUpdate,
    StatsResponse,
)
from app.services.intelligence import analyze_email

router = APIRouter(prefix="/emails", tags=["emails"])


def _apply_analysis(email: Email, subject: str, body: str) -> None:
    result = analyze_email(subject, body)
    email.category = result.category
    email.priority = result.priority
    email.summary = result.summary
    email.analysis_source = result.source
    email.processing_status = "processed"


@router.post("", response_model=EmailRead, status_code=status.HTTP_201_CREATED)
def create_email(payload: EmailCreate, db: Session = Depends(get_db)):
    email = Email(
        sender=payload.sender.strip(),
        subject=payload.subject.strip(),
        body=payload.body.strip(),
        category=payload.category,
        priority=payload.priority,
        summary=payload.summary,
        processing_status="pending",
        analysis_source="none",
    )
    provided = payload.category and payload.priority and payload.summary
    if provided:
        email.processing_status = "processed"
        email.analysis_source = "manual"
    elif payload.analyze:
        try:
            _apply_analysis(email, email.subject, email.body)
        except Exception:
            email.processing_status = "failed"
    db.add(email)
    db.commit()
    db.refresh(email)
    return email


@router.get("", response_model=EmailListResponse)
def list_emails(
    db: Session = Depends(get_db),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: str | None = None,
    category: str | None = None,
    priority: str | None = None,
    status_filter: str | None = Query(default=None, alias="status"),
):
    stmt = select(Email)
    count_stmt = select(func.count(Email.id))

    if search:
        like = f"%{search.strip()}%"
        search_filter = or_(
            Email.sender.ilike(like),
            Email.subject.ilike(like),
            Email.body.ilike(like),
            Email.summary.ilike(like),
        )
        stmt = stmt.where(search_filter)
        count_stmt = count_stmt.where(search_filter)
    if category:
        stmt = stmt.where(Email.category == category)
        count_stmt = count_stmt.where(Email.category == category)
    if priority:
        stmt = stmt.where(Email.priority == priority)
        count_stmt = count_stmt.where(Email.priority == priority)
    if status_filter:
        stmt = stmt.where(Email.processing_status == status_filter)
        count_stmt = count_stmt.where(Email.processing_status == status_filter)

    total = db.scalar(count_stmt) or 0
    offset = (page - 1) * page_size
    items = db.scalars(stmt.order_by(Email.created_at.desc()).offset(offset).limit(page_size)).all()
    return EmailListResponse(items=items, total=total, page=page, page_size=page_size)


@router.get("/stats", response_model=StatsResponse)
def email_stats(db: Session = Depends(get_db)):
    emails = db.scalars(select(Email)).all()
    by_category: dict[str, int] = {}
    by_priority: dict[str, int] = {}
    sources: dict[str, int] = {}
    high = processed = pending = 0
    for email in emails:
        if email.category:
            by_category[email.category] = by_category.get(email.category, 0) + 1
        if email.priority:
            by_priority[email.priority] = by_priority.get(email.priority, 0) + 1
            if email.priority == "High":
                high += 1
        sources[email.analysis_source] = sources.get(email.analysis_source, 0) + 1
        if email.processing_status == "processed":
            processed += 1
        if email.processing_status == "pending":
            pending += 1
    return StatsResponse(
        total=len(emails),
        high_priority=high,
        processed=processed,
        pending=pending,
        by_category=by_category,
        by_priority=by_priority,
        analysis_sources=sources,
    )


@router.get("/{email_id}", response_model=EmailRead)
def get_email(email_id: int, db: Session = Depends(get_db)):
    email = db.get(Email, email_id)
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    return email


@router.patch("/{email_id}", response_model=EmailRead)
def update_email(email_id: int, payload: EmailUpdate, db: Session = Depends(get_db)):
    email = db.get(Email, email_id)
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(status_code=422, detail="No fields to update")
    for key, value in data.items():
        setattr(email, key, value)
    email.updated_at = datetime.now(timezone.utc)
    if payload.category or payload.priority or payload.summary:
        email.analysis_source = "manual"
        email.processing_status = "processed"
    db.commit()
    db.refresh(email)
    return email


@router.post("/{email_id}/analyze", response_model=EmailRead)
def reanalyze_email(email_id: int, db: Session = Depends(get_db)):
    email = db.get(Email, email_id)
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    try:
        _apply_analysis(email, email.subject, email.body)
    except Exception as exc:  # noqa: BLE001
        email.processing_status = "failed"
        db.commit()
        raise HTTPException(status_code=502, detail=f"Analysis failed: {exc}") from exc
    email.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(email)
    return email


@router.delete("/{email_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_email(email_id: int, db: Session = Depends(get_db)):
    email = db.get(Email, email_id)
    if not email:
        raise HTTPException(status_code=404, detail="Email not found")
    db.delete(email)
    db.commit()
