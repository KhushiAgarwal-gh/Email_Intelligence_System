from app.utils.text import normalize

CATEGORIES = ("Work", "Personal", "Finance", "Promotions", "Support", "Other")

KEYWORD_MAP = {
    "Finance": (
        "invoice",
        "payment",
        "bank",
        "salary",
        "payroll",
        "refund",
        "statement",
        "tax",
        "receipt",
        "overdue",
    ),
    "Support": (
        "ticket",
        "support",
        "issue",
        "bug",
        "outage",
        "error",
        "help desk",
        "incident",
        "not working",
    ),
    "Promotions": (
        "unsubscribe",
        "discount",
        "sale",
        "offer",
        "promo",
        "newsletter",
        "deal",
        "% off",
        "limited time",
    ),
    "Work": (
        "meeting",
        "standup",
        "project",
        "deadline",
        "quarter",
        "sync",
        "agenda",
        "kickoff",
        "sprint",
        "client",
        "report",
    ),
    "Personal": (
        "birthday",
        "family",
        "dinner",
        "weekend",
        "vacation",
        "wedding",
        "catch up",
        "love",
    ),
}


def classify_email(subject: str, body: str) -> str:
    text = normalize(f"{subject} {body}")
    scores: dict[str, int] = {name: 0 for name in CATEGORIES}
    for category, keywords in KEYWORD_MAP.items():
        for keyword in keywords:
            if keyword in text:
                scores[category] += 1
    best = max(CATEGORIES, key=lambda name: scores[name])
    return best if scores[best] else "Other"
