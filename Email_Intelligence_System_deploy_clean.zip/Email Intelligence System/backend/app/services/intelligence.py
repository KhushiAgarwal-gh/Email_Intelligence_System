import json
import logging
from typing import Any

import httpx

from app.config import LLM_API_BASE, LLM_API_KEY, LLM_MODEL
from app.services.classifier import CATEGORIES, classify_email
from app.services.priority import PRIORITIES, detect_priority
from app.services.summarizer import summarize_email

logger = logging.getLogger(__name__)


class AnalysisResult:
    def __init__(self, category: str, priority: str, summary: str, source: str) -> None:
        self.category = category
        self.priority = priority
        self.summary = summary
        self.source = source


def analyze_with_fallback(subject: str, body: str) -> AnalysisResult:
    return AnalysisResult(
        category=classify_email(subject, body),
        priority=detect_priority(subject, body),
        summary=summarize_email(subject, body),
        source="fallback",
    )


def _parse_llm_payload(data: Any) -> AnalysisResult | None:
    if not isinstance(data, dict):
        return None
    category = str(data.get("category", "")).strip()
    priority = str(data.get("priority", "")).strip()
    summary = str(data.get("summary", "")).strip()
    if category not in CATEGORIES or priority not in PRIORITIES or not summary:
        return None
    return AnalysisResult(category=category, priority=priority, summary=summary, source="llm")


def analyze_with_llm(subject: str, body: str) -> AnalysisResult:
    prompt = {
        "model": LLM_MODEL,
        "temperature": 0.1,
        "response_format": {"type": "json_object"},
        "messages": [
            {
                "role": "system",
                "content": (
                    "You classify emails. Return JSON with keys category, priority, summary. "
                    f"category must be one of: {', '.join(CATEGORIES)}. "
                    f"priority must be one of: {', '.join(PRIORITIES)}. "
                    "summary must be 1-2 concise sentences."
                ),
            },
            {
                "role": "user",
                "content": f"Subject: {subject}\n\nBody:\n{body[:4000]}",
            },
        ],
    }
    headers = {
        "Authorization": f"Bearer {LLM_API_KEY}",
        "Content-Type": "application/json",
    }
    url = f"{LLM_API_BASE}/chat/completions"
    try:
        with httpx.Client(timeout=20.0) as client:
            response = client.post(url, headers=headers, json=prompt)
        if response.status_code == 429:
            logger.warning("LLM rate limited; using rule-based fallback.")
            return analyze_with_fallback(subject, body)
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        parsed = _parse_llm_payload(json.loads(content))
        if parsed is None:
            logger.warning("LLM returned an invalid payload; using fallback.")
            return analyze_with_fallback(subject, body)
        return parsed
    except Exception as exc:  # noqa: BLE001
        logger.warning("LLM analysis failed (%s); using fallback.", exc)
        return analyze_with_fallback(subject, body)


def analyze_email(subject: str, body: str) -> AnalysisResult:
    if LLM_API_KEY:
        return analyze_with_llm(subject, body)
    return analyze_with_fallback(subject, body)
