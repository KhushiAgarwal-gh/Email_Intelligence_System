from app.utils.text import normalize

PRIORITIES = ("High", "Medium", "Low")

HIGH_KEYWORDS = (
    "urgent",
    "asap",
    "immediately",
    "action required",
    "overdue",
    "outage",
    "tonight",
    "eod",
    "escalate",
    "critical",
    "deadline today",
    "security",
)
MEDIUM_KEYWORDS = (
    "meeting",
    "schedule",
    "follow up",
    "reminder",
    "please review",
    "this week",
    "invoice",
    "update",
    "request",
)
LOW_KEYWORDS = (
    "newsletter",
    "unsubscribe",
    "promotion",
    "fyi",
    "no action",
    "digest",
    "sale",
    "optional",
)


def detect_priority(subject: str, body: str) -> str:
    text = normalize(f"{subject} {body}")
    if any(keyword in text for keyword in HIGH_KEYWORDS):
        return "High"
    if any(keyword in text for keyword in LOW_KEYWORDS) and not any(
        keyword in text for keyword in MEDIUM_KEYWORDS
    ):
        return "Low"
    if any(keyword in text for keyword in MEDIUM_KEYWORDS):
        return "Medium"
    return "Medium"
