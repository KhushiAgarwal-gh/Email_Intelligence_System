from app.utils.text import first_sentences


def summarize_email(subject: str, body: str) -> str:
    body_summary = first_sentences(body)
    if subject.strip():
        return f"{subject.strip()} — {body_summary}"
    return body_summary
