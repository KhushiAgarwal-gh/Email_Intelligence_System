import re


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().lower()


def first_sentences(text: str, max_chars: int = 220) -> str:
    cleaned = re.sub(r"\s+", " ", text).strip()
    if not cleaned:
        return "No summary available."
    parts = re.split(r"(?<=[.!?])\s+", cleaned)
    summary = " ".join(parts[:2]).strip()
    if len(summary) > max_chars:
        summary = summary[: max_chars - 1].rstrip() + "…"
    return summary
