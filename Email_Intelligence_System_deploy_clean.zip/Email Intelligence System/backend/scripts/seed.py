"""Load fictional demo emails. Safe to run more than once."""

from sqlalchemy import select

from app.database import Base, SessionLocal, engine
from app.models import Email
from app.services.intelligence import analyze_email

DEMO_EMAILS = [
    {
        "seed_key": "demo-1",
        "sender": "jordan.lee@northwind.dev",
        "subject": "Urgent: production outage on checkout",
        "body": (
            "Checkout is returning 500 errors for about 12% of customers. "
            "Please join the incident channel immediately and share status by 10:30."
        ),
    },
    {
        "seed_key": "demo-2",
        "sender": "priya.nair@northwind.dev",
        "subject": "Sprint planning agenda for Thursday",
        "body": (
            "Sharing the agenda for Thursday's planning meeting. Please review the backlog "
            "and add estimates before the kickoff."
        ),
    },
    {
        "seed_key": "demo-3",
        "sender": "billing@acme-finance.example",
        "subject": "Invoice INV-1042 is overdue",
        "body": (
            "Invoice INV-1042 for $1,280 was due last Friday. Please send payment or "
            "reply with a revised date to avoid a late fee."
        ),
    },
    {
        "seed_key": "demo-4",
        "sender": "offers@shoply.example",
        "subject": "This weekend only: 40% off laptops",
        "body": (
            "Flash sale on selected laptops. Use code WEEKEND40. Unsubscribe anytime "
            "from the footer of this newsletter."
        ),
    },
    {
        "seed_key": "demo-5",
        "sender": "maya@familymail.example",
        "subject": "Dinner on Saturday?",
        "body": (
            "Are you free Saturday evening? I was thinking of trying the new Italian place "
            "near the park. No rush if you already have plans."
        ),
    },
    {
        "seed_key": "demo-6",
        "sender": "support@cloudbox.example",
        "subject": "Ticket #8841: login loop on mobile",
        "body": (
            "A customer reports that the mobile app stays on the login screen after MFA. "
            "We have a HAR file attached in the portal. Please investigate this issue."
        ),
    },
    {
        "seed_key": "demo-7",
        "sender": "alex.chen@northwind.dev",
        "subject": "FYI: office snacks restocked",
        "body": "The kitchen is restocked. No action needed, just a friendly update.",
    },
    {
        "seed_key": "demo-8",
        "sender": "payroll@northwind.dev",
        "subject": "Payroll confirmation for March",
        "body": (
            "Salary for March will land on Friday. Please confirm your bank statement "
            "and reply if a receipt is missing."
        ),
    },
]


def seed() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    created = 0
    skipped = 0
    try:
        for item in DEMO_EMAILS:
            exists = db.scalar(select(Email).where(Email.seed_key == item["seed_key"]))
            if exists:
                skipped += 1
                continue
            analysis = analyze_email(item["subject"], item["body"])
            email = Email(
                sender=item["sender"],
                subject=item["subject"],
                body=item["body"],
                seed_key=item["seed_key"],
                category=analysis.category,
                priority=analysis.priority,
                summary=analysis.summary,
                analysis_source=analysis.source,
                processing_status="processed",
            )
            db.add(email)
            created += 1
        db.commit()
    finally:
        db.close()
    print(f"Seed complete. created={created} skipped={skipped}")


if __name__ == "__main__":
    seed()
