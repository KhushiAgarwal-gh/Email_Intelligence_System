def _create(client, **overrides):
    payload = {
        "sender": "casey@northwind.dev",
        "subject": "Sprint planning agenda",
        "body": "Please review the project backlog before Thursday's meeting.",
    }
    payload.update(overrides)
    return client.post("/emails", json=payload)


def test_create_email_uses_fallback_analysis(client):
    response = _create(client)
    assert response.status_code == 201
    body = response.json()
    assert body["id"] >= 1
    assert body["category"] == "Work"
    assert body["priority"] in {"High", "Medium", "Low"}
    assert body["summary"]
    assert body["analysis_source"] == "fallback"
    assert body["processing_status"] == "processed"


def test_create_validation_error(client):
    response = client.post("/emails", json={"sender": "", "subject": "x", "body": "y"})
    assert response.status_code == 422


def test_list_search_and_pagination(client):
    _create(client, subject="Invoice overdue", body="Payment is overdue for INV-9.")
    _create(client, subject="Birthday dinner", body="Family dinner this weekend.")
    listed = client.get("/emails", params={"search": "invoice", "page": 1, "page_size": 10})
    assert listed.status_code == 200
    data = listed.json()
    assert data["total"] == 1
    assert data["items"][0]["subject"].lower().find("invoice") >= 0


def test_get_update_delete_email(client):
    created = _create(client).json()
    email_id = created["id"]
    fetched = client.get(f"/emails/{email_id}")
    assert fetched.status_code == 200
    updated = client.patch(f"/emails/{email_id}", json={"priority": "High", "category": "Work"})
    assert updated.status_code == 200
    assert updated.json()["priority"] == "High"
    assert updated.json()["analysis_source"] == "manual"
    missing = client.get("/emails/9999")
    assert missing.status_code == 404
    deleted = client.delete(f"/emails/{email_id}")
    assert deleted.status_code == 204
    assert client.get(f"/emails/{email_id}").status_code == 404


def test_stats_endpoint(client):
    _create(client, subject="Urgent outage", body="Critical production outage right now.")
    stats = client.get("/emails/stats")
    assert stats.status_code == 200
    body = stats.json()
    assert body["total"] == 1
    assert "by_category" in body
