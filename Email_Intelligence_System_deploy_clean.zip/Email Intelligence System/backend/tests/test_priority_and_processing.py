from app.services.classifier import classify_email
from app.services.intelligence import analyze_with_fallback
from app.services.priority import detect_priority


def test_high_priority_keywords():
    assert detect_priority("Urgent action required", "Please fix this immediately") == "High"


def test_low_priority_newsletter():
    assert detect_priority("Weekly newsletter", "Unsubscribe from this promotion any time") == "Low"


def test_medium_priority_meeting():
    assert detect_priority("Meeting reminder", "Please review the schedule this week") == "Medium"


def test_classification_finance_and_support():
    assert classify_email("Invoice INV-12", "Your payment receipt is attached") == "Finance"
    assert classify_email("Ticket 44", "The app has a bug and is not working") == "Support"


def test_fallback_analysis_shape():
    result = analyze_with_fallback("Deadline today for the project report", "Please send the report by EOD.")
    assert result.source == "fallback"
    assert result.category in {"Work", "Personal", "Finance", "Promotions", "Support", "Other"}
    assert result.priority in {"High", "Medium", "Low"}
    assert "report" in result.summary.lower() or "Deadline" in result.summary
