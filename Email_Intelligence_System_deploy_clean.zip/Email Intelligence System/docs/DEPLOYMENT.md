# Deployment guide (Render)

## Before deploying
- Keep real email data out of this demo. The API currently has no authentication and its create/update/delete endpoints are public if deployed as-is.
- Do not commit `.env` files or API keys. Configure secrets in Render's Environment settings.
- This project uses a frontend and API as separate Render services, plus a managed PostgreSQL database.

## Deploy with Render Blueprint
1. Push this cleaned project folder to a GitHub repository (default branch `main`).
2. In Render, choose **New + → Blueprint**, connect the repository, and apply `render.yaml`.
3. When asked for `FRONTEND_ORIGINS`, create the frontend service first if the Blueprint UI allows staged creation, then set the value to the exact frontend URL, e.g. `https://email-intelligence-web.onrender.com`. No trailing slash.
4. Set the frontend service's `NEXT_PUBLIC_API_URL` to the exact backend URL, e.g. `https://email-intelligence-api.onrender.com` (no trailing slash). Because this variable is used by Next.js in the browser, trigger a fresh frontend deploy after changing it.
5. Optionally set `LLM_API_KEY` on the backend service. Leave it empty to use the rule-based fallback. Never put this key in frontend variables.
6. Wait for both services to finish deploying. Open `https://<backend-url>/health`; it should report database connected. Open `https://<backend-url>/docs` to inspect the API, then open the frontend URL.
7. If the frontend reports a network/CORS error, verify `NEXT_PUBLIC_API_URL` and `FRONTEND_ORIGINS` exactly match the deployed service URLs, then redeploy the affected service.

## Important
- Free hosting may sleep, have cold starts, or change plan limits. Check Render's current pricing before creating resources.
- Do not use this public demo for private/personal inbox contents until authentication and authorization are implemented.
- A GitHub Actions workflow file does not prove CI passed; check the repository's Actions tab after pushing.
