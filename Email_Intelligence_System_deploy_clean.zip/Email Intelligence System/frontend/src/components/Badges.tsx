const categoryStyles: Record<string, string> = {
  Work: "bg-indigo-50 text-indigo-700 ring-indigo-100",
  Personal: "bg-rose-50 text-rose-700 ring-rose-100",
  Finance: "bg-emerald-50 text-emerald-700 ring-emerald-100",
  Promotions: "bg-amber-50 text-amber-700 ring-amber-100",
  Support: "bg-sky-50 text-sky-700 ring-sky-100",
  Other: "bg-slate-100 text-slate-700 ring-slate-200",
};

const priorityStyles: Record<string, string> = {
  High: "bg-red-50 text-red-700 ring-red-100",
  Medium: "bg-orange-50 text-orange-700 ring-orange-100",
  Low: "bg-slate-100 text-slate-600 ring-slate-200",
};

export function CategoryBadge({ value }: { value?: string | null }) {
  const label = value || "Uncategorized";
  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ${categoryStyles[label] || categoryStyles.Other}`}>
      {label}
    </span>
  );
}

export function PriorityBadge({ value }: { value?: string | null }) {
  const label = value || "Unknown";
  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ${priorityStyles[label] || priorityStyles.Low}`}>
      {label}
    </span>
  );
}
