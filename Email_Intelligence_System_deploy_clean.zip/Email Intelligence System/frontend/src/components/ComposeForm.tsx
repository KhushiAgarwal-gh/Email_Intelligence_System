"use client";

import { FormEvent, useState } from "react";

export function ComposeForm({
  onSubmit,
  busy,
}: {
  onSubmit: (payload: { sender: string; subject: string; body: string }) => Promise<void>;
  busy: boolean;
}) {
  const [sender, setSender] = useState("alex.chen@northwind.dev");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    try {
      await onSubmit({ sender, subject, body });
      setSubject("");
      setBody("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save email");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3 rounded-2xl border border-slate-100 bg-white p-4">
      <h3 className="font-semibold">Import an email</h3>
      <input
        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
        value={sender}
        onChange={(event) => setSender(event.target.value)}
        placeholder="sender@example.com"
        required
      />
      <input
        className="w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
        value={subject}
        onChange={(event) => setSubject(event.target.value)}
        placeholder="Subject"
        required
      />
      <textarea
        className="h-28 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
        value={body}
        onChange={(event) => setBody(event.target.value)}
        placeholder="Paste the email body"
        required
      />
      {error ? <p className="text-sm text-red-600">{error}</p> : null}
      <button
        type="submit"
        disabled={busy}
        className="w-full rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
      >
        {busy ? "Analyzing…" : "Save and analyze"}
      </button>
    </form>
  );
}
