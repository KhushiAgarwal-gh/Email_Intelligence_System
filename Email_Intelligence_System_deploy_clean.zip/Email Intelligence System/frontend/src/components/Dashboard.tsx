"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { analyzeEmail, ApiError, createEmail, deleteEmail, getStats, listEmails } from "@/lib/api";
import { DEMO_EMAILS, DEMO_STATS } from "@/lib/demo-emails";
import { Email, Stats } from "@/lib/types";
import { ComposeForm } from "./ComposeForm";
import { EmailDetail } from "./EmailDetail";
import { EmailList } from "./EmailList";
import { StatsCards } from "./StatsCards";

const CATEGORIES = ["Work", "Personal", "Finance", "Promotions", "Support", "Other"];
const PRIORITIES = ["High", "Medium", "Low"];

export function Dashboard() {
  const [emails, setEmails] = useState<Email[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [selected, setSelected] = useState<Email | null>(null);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [priority, setPriority] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usingDemo, setUsingDemo] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [list, statsData] = await Promise.all([
        listEmails({ search, category, priority }),
        getStats(),
      ]);
      if (list.total === 0 && !search && !category && !priority) {
        setEmails(DEMO_EMAILS);
        setStats(DEMO_STATS);
        setUsingDemo(true);
        setSelected(DEMO_EMAILS[0]);
      } else {
        setEmails(list.items);
        setStats(statsData);
        setUsingDemo(false);
        setSelected(list.items[0] || null);
      }
    } catch (err) {
      setUsingDemo(true);
      setEmails(DEMO_EMAILS);
      setStats(DEMO_STATS);
      setSelected(DEMO_EMAILS[0]);
      setError(err instanceof ApiError ? err.message : "API unavailable. Showing demo inbox.");
    } finally {
      setLoading(false);
    }
  }, [search, category, priority]);

  useEffect(() => {
    const timeout = setTimeout(() => {
      void load();
    }, 200);
    return () => clearTimeout(timeout);
  }, [load]);

  const filteredDemo = useMemo(() => {
    return emails.filter((email) => {
      const haystack = `${email.sender} ${email.subject} ${email.body} ${email.summary}`.toLowerCase();
      const matchesSearch = search ? haystack.includes(search.toLowerCase()) : true;
      const matchesCategory = category ? email.category === category : true;
      const matchesPriority = priority ? email.priority === priority : true;
      return matchesSearch && matchesCategory && matchesPriority;
    });
  }, [emails, search, category, priority]);

  const visibleEmails = usingDemo ? filteredDemo : emails;

  async function handleCreate(payload: { sender: string; subject: string; body: string }) {
    setBusy(true);
    try {
      await createEmail(payload);
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete(id: number) {
    setBusy(true);
    try {
      await deleteEmail(id);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  async function handleAnalyze(id: number) {
    setBusy(true);
    try {
      const updated = await analyzeEmail(id);
      setEmails((current) => current.map((email) => (email.id === id ? updated : email)));
      setSelected(updated);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Analyze failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-7xl flex-col gap-6 px-4 py-6 lg:px-8">
      <header className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-sm font-medium text-indigo-600">Portfolio project</p>
          <h1 className="text-3xl font-semibold tracking-tight text-slate-900">Email Intelligence</h1>
          <p className="mt-1 max-w-2xl text-sm text-slate-500">
            Classify, prioritize, and summarize inbox messages. The API uses an LLM when a key is set, otherwise a rule-based fallback.
          </p>
        </div>
        {usingDemo ? (
          <span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-800 ring-1 ring-amber-100">
            Demo data — seed the database to replace this inbox
          </span>
        ) : null}
      </header>

      {error ? (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">{error}</div>
      ) : null}

      <StatsCards stats={stats} loading={loading} />

      <div className="grid gap-6 xl:grid-cols-[280px_1fr_1.1fr]">
        <aside className="space-y-4">
          <div className="rounded-2xl border border-white/80 bg-white/80 p-4 shadow-sm">
            <label className="text-xs font-semibold uppercase tracking-wide text-slate-500">Search</label>
            <input
              className="mt-2 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
              placeholder="Sender, subject, or body"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
            <label className="mt-4 block text-xs font-semibold uppercase tracking-wide text-slate-500">Category</label>
            <select
              className="mt-2 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
              value={category}
              onChange={(event) => setCategory(event.target.value)}
            >
              <option value="">All</option>
              {CATEGORIES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <label className="mt-4 block text-xs font-semibold uppercase tracking-wide text-slate-500">Priority</label>
            <select
              className="mt-2 w-full rounded-xl border border-slate-200 px-3 py-2 text-sm"
              value={priority}
              onChange={(event) => setPriority(event.target.value)}
            >
              <option value="">All</option>
              {PRIORITIES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
          <ComposeForm onSubmit={handleCreate} busy={busy} />
        </aside>

        <section className="overflow-hidden rounded-2xl border border-white/80 bg-white/80 shadow-sm">
          <div className="border-b border-slate-100 px-5 py-3 text-sm font-medium text-slate-600">
            Inbox · {visibleEmails.length}
          </div>
          <EmailList emails={visibleEmails} selectedId={selected?.id ?? null} loading={loading} onSelect={setSelected} />
        </section>

        <section className="min-h-[480px] overflow-hidden rounded-2xl border border-white/80 bg-white/90 shadow-sm">
          <EmailDetail email={selected} onDelete={handleDelete} onAnalyze={handleAnalyze} busy={busy} />
        </section>
      </div>
    </div>
  );
}
