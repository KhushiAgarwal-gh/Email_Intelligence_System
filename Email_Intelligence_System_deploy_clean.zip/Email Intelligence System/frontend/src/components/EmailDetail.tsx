import { CategoryBadge, PriorityBadge } from "./Badges";
import { Email } from "@/lib/types";

export function EmailDetail({
  email,
  onDelete,
  onAnalyze,
  busy,
}: {
  email: Email | null;
  onDelete: (id: number) => void;
  onAnalyze: (id: number) => void;
  busy: boolean;
}) {
  if (!email) {
    return (
      <div className="flex h-full items-center justify-center p-8 text-sm text-slate-500">
        Select an email to read the summary and full body.
      </div>
    );
  }

  const isDemo = email.id < 0;

  return (
    <article className="flex h-full flex-col gap-5 p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">{email.subject}</h2>
          <p className="mt-1 text-sm text-slate-500">{email.sender}</p>
        </div>
        <div className="flex gap-2">
          <PriorityBadge value={email.priority} />
          <CategoryBadge value={email.category} />
        </div>
      </div>
      <div className="rounded-2xl bg-indigo-50/70 p-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-indigo-700">Summary</p>
        <p className="mt-2 text-sm leading-6 text-slate-700">{email.summary || "No summary yet."}</p>
        <p className="mt-3 text-xs text-slate-500">
          Source: {email.analysis_source} · Status: {email.processing_status}
        </p>
      </div>
      <div className="flex-1 overflow-auto rounded-2xl border border-slate-100 bg-white p-4 text-sm leading-7 text-slate-700">
        {email.body}
      </div>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={busy || isDemo}
          onClick={() => onAnalyze(email.id)}
          className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-40"
        >
          Re-analyze
        </button>
        <button
          type="button"
          disabled={busy || isDemo}
          onClick={() => onDelete(email.id)}
          className="rounded-xl border border-red-200 px-4 py-2 text-sm font-medium text-red-700 disabled:opacity-40"
        >
          Delete
        </button>
      </div>
    </article>
  );
}
