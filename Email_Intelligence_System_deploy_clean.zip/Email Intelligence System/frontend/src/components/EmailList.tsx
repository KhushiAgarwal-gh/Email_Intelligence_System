import { CategoryBadge, PriorityBadge } from "./Badges";
import { Email } from "@/lib/types";

export function EmailList({
  emails,
  selectedId,
  loading,
  onSelect,
}: {
  emails: Email[];
  selectedId: number | null;
  loading: boolean;
  onSelect: (email: Email) => void;
}) {
  if (loading) {
    return (
      <div className="space-y-3 p-4">
        {[1, 2, 3, 4].map((item) => (
          <div key={item} className="h-24 animate-pulse rounded-xl bg-slate-100" />
        ))}
      </div>
    );
  }

  if (!emails.length) {
    return <p className="p-6 text-sm text-slate-500">No emails match these filters.</p>;
  }

  return (
    <ul className="divide-y divide-slate-100">
      {emails.map((email) => {
        const active = selectedId === email.id;
        return (
          <li key={email.id}>
            <button
              type="button"
              onClick={() => onSelect(email)}
              className={`w-full px-5 py-4 text-left transition ${active ? "bg-indigo-50" : "hover:bg-slate-50"}`}
            >
              <div className="flex items-center justify-between gap-3">
                <p className="truncate text-sm font-medium text-slate-900">{email.sender}</p>
                <PriorityBadge value={email.priority} />
              </div>
              <p className="mt-1 truncate font-semibold">{email.subject}</p>
              <p className="mt-1 line-clamp-2 text-sm text-slate-500">{email.summary || email.body}</p>
              <div className="mt-2">
                <CategoryBadge value={email.category} />
              </div>
            </button>
          </li>
        );
      })}
    </ul>
  );
}
