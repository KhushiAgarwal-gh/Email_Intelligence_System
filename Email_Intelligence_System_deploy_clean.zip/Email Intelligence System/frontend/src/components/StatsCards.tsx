import { Stats } from "@/lib/types";

export function StatsCards({ stats, loading }: { stats: Stats | null; loading: boolean }) {
  const cards = [
    { label: "Inbox", value: stats?.total ?? 0 },
    { label: "High priority", value: stats?.high_priority ?? 0 },
    { label: "Processed", value: stats?.processed ?? 0 },
    { label: "Pending", value: stats?.pending ?? 0 },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => (
        <div key={card.label} className="rounded-2xl border border-white/80 bg-white/80 p-5 shadow-sm backdrop-blur">
          <p className="text-sm text-slate-500">{card.label}</p>
          <p className="mt-2 text-3xl font-semibold tracking-tight">{loading ? "…" : card.value}</p>
        </div>
      ))}
    </div>
  );
}
