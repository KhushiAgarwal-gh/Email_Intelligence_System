import { Email, EmailListResponse, Stats } from "./types";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

export class ApiError extends Error {
  constructor(
    message: string,
    public status?: number,
  ) {
    super(message);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_URL}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
      cache: "no-store",
    });
  } catch {
    throw new ApiError("Cannot reach the API. Start it with docker compose or uvicorn.");
  }
  if (!response.ok) {
    const detail = await response.text();
    throw new ApiError(detail || "Request failed", response.status);
  }
  if (response.status === 204) {
    return undefined as T;
  }
  return response.json() as Promise<T>;
}

export function listEmails(params: {
  search?: string;
  category?: string;
  priority?: string;
  page?: number;
}): Promise<EmailListResponse> {
  const query = new URLSearchParams();
  if (params.search) query.set("search", params.search);
  if (params.category) query.set("category", params.category);
  if (params.priority) query.set("priority", params.priority);
  query.set("page", String(params.page || 1));
  query.set("page_size", "50");
  return request(`/emails?${query.toString()}`);
}

export function getStats(): Promise<Stats> {
  return request("/emails/stats");
}

export function createEmail(payload: {
  sender: string;
  subject: string;
  body: string;
}): Promise<Email> {
  return request("/emails", { method: "POST", body: JSON.stringify(payload) });
}

export function deleteEmail(id: number): Promise<void> {
  return request(`/emails/${id}`, { method: "DELETE" });
}

export function analyzeEmail(id: number): Promise<Email> {
  return request(`/emails/${id}/analyze`, { method: "POST" });
}
