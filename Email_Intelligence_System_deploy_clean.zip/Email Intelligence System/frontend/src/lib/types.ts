export type Category = "Work" | "Personal" | "Finance" | "Promotions" | "Support" | "Other";
export type Priority = "High" | "Medium" | "Low";

export type Email = {
  id: number;
  sender: string;
  subject: string;
  body: string;
  category: string | null;
  priority: string | null;
  summary: string | null;
  processing_status: string;
  analysis_source: string;
  created_at: string;
  updated_at: string;
};

export type EmailListResponse = {
  items: Email[];
  total: number;
  page: number;
  page_size: number;
};

export type Stats = {
  total: number;
  high_priority: number;
  processed: number;
  pending: number;
  by_category: Record<string, number>;
  by_priority: Record<string, number>;
  analysis_sources: Record<string, number>;
};
